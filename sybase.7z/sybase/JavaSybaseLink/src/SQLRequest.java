/**
 *
 * @author rod
 */
public class SQLRequest {
	int msgId;
	String sql;
	long sentTime;
	long javaStartTime;
}
